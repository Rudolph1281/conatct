# crash-course-CMS
Django customer management platform

Courier Management System

Run this project on your machine you need to follow this steps

Step 1 Download the project and extract it

Step 2 open command prompt change directory(cd) where there is your project until you see the files manage.py and sqlite3

Step 3 Create Virtual Environment 
	pip install virtualenv 
	pip install virtualenvwrapper-win
	
	mkvirtualenv "name-of-Env"

Step 4 pip install the django

Step 5 pip install django-filter django-storages boto3 pillow

Step 6 make migrations by using this command line python manage.py makemigrations

Step 7 python manage.py migrate

Step 8 python manage.py runserver

then you can access all the pages from here


thank you